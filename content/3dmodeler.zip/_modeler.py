import os
import pygame
os.system('cls')
import random, sys, math, time
import binascii, shutil, io, struct
from PIL import Image
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
import numpy as np
from PIL import Image, ImageDraw

import tracemalloc

tracemalloc.start()

#0 = x min, 1 = x max, 2 = y min, 3 = y max
bttnCordLookup = [
[1,1,42,8], #ID:0 - New
[1,9,42,16], #ID:1 - Load
[44,1,98,16], #ID:2 - Save
[1,18,20,33], #ID:3 - Add
[22,18,43,33], #ID:4 - ExView
[45,18,64,33], #ID:5 - Delete
[66,18,81,33], #ID:6 - Select Left
[83,18,98,33], #ID:7 - Select Right
[1,35,13,46], #ID:8 - Model Mode Texture Planes
[15,35,27,46], #ID:9 - Model Mode Collision
[56,35,68,46], #ID:10 - Select Mode Object
[70,35,84,46], #ID:11 - Select Mode Plane
[86,35,98,46], #ID:12 - Select Mode Vertex
[9,59,27,67], #ID:13 - Level ID
[29,59,39,67], #ID:14 - Level BG
[73,59,91,67], #ID:15 - Texture ID
[21,79,31,87], #ID:16 - Group
[50,79,54,86], #ID:17 - Side >
[56,79,60,86], #ID:18 - Side <
[86,80,92,86], #ID:19 - Ignore
[5,89,95,97], #ID:20 - Coll X
[5,99,95,107], #ID:21 - Coll Y
[5,109,95,117], #ID:22 - Coll Z
[5,129,95,137], #ID:23 - Plane X
[5,139,95,147], #ID:24 - Plane Y
[5,149,95,157], #ID:25 - Plane Z
[5,169,95,177], #ID:26 - Object X
[5,179,95,187], #ID:27 - Object Y
[5,189,95,197], #ID:28 - Object Z
[13,199,95,207], #ID:29 - FD1
[13,209,95,217], #ID:30 - FD2
[13,219,95,227], #ID:31 - FD3
[13,229,95,237], #ID:32 - FD4
[13,239,95,247], #ID:33 - FD5
[13,249,95,257], #ID:34 - FD6
[13,259,95,267], #ID:35 - FD7
[13,269,95,277], #ID:36 - FD8
[13,279,39,287], #ID:37 - ID1
[53,279,79,287], #ID:38 - ID2
[13,289,39,297], #ID:39 - ID3
[53,289,79,297], #ID:40 - ID4
[13,299,39,307], #ID:41 - ID5
[53,299,79,307], #ID:42 - ID6
[13,309,39,317], #ID:43 - ID7
[53,309,79,317] #ID:44 - ID8
]

exView = 0
#0 = draw only current type
#1 = draw supportive type
#2 = draw odd type
#3 = draw all

bg = "00"
lvId = "0000"
mMode = "tex"
sMode = "pln"

select = [0,0,0] #obj, pln, ver

texData = []
colData = []
objData = []

textSelect = [0,""]
'''
ids

0 - (not in a field)
1 - level id (hex)
2 - level bg (hex)
3 - texture (hex)
4 - group (hex)
5 - col x
6 - col y
7 - col z
8 - pln x
9 - pln y
10 - pln z
11 - obj x
12 - obj y
13 - obj z
14 - fd1
15 - fd2
16 - fd3
17 - fd4
18 - fd5
19 - fd6
20 - fd7
21 - fd8
22 - id1 (int)
23 - id2 (int)
24 - id3 (int)
25 - id4 (int)
26 - id5 (int)
27 - id6 (int)
28 - id7 (int)
29 - id8 (int)
'''

selAcc = [0,1,0,1]

pygame.init()
res = (580, 360)
pygame.display.set_icon(pygame.image.load("img//icon.png"))
pygame.display.set_caption("Modeler")
pygame.display.set_mode(res, DOUBLEBUF|OPENGL)
gluPerspective(1, (res[0]/res[1]), 0, 50)
glTranslatef(0.0, 0.0, -5)

def CreateTexture(Path):
	if not Path[0] == "_":
		textureSurface = pygame.image.load(Path)
	else:
		Map = np.zeros((1, 1, 4), dtype=np.uint8)
		Map[0,0,0] = int(Path[1:3], 16)
		Map[0,0,1] = int(Path[3:5], 16)
		Map[0,0,2] = int(Path[5:7], 16)
		Map[0,0,3] = int(Path[7:9], 16)
		P = Image.fromarray(np.array(Map, dtype=np.uint8), "RGBA")
		textureSurface = pygame.image.fromstring(P.convert("RGBA").tobytes(), P.size, P.mode)
	textureData = pygame.image.tostring(textureSurface, "RGBA", 1)
	width = textureSurface.get_width()
	height = textureSurface.get_height()
	texid = glGenTextures(1)
	return [texid, Path, width, height, textureSurface ,textureData]

commonTextures = [CreateTexture("_FF0000FF"), #red
CreateTexture("_00FF00FF"), #green
CreateTexture("_0000FFFF"), #blue
CreateTexture("_FFFFFFFF"), #white
CreateTexture("_7F7F7F3F"), #axis label plane
CreateTexture("img//axis.png"), #XYZ label
CreateTexture("img//pannel.png"), #control pannel
CreateTexture("_5F5F5FFF"), #obj textures
CreateTexture("_6F6F6FFF"),
CreateTexture("_7F7F7FFF"),
CreateTexture("_8F8F8FFF"),
CreateTexture("_9F9F9FFF"),
CreateTexture("img//topselect.png"), #sMode and mMode select
CreateTexture("img//bottomselect.png"), #side select
CreateTexture("_6788BCFF"), #ignore highlight
CreateTexture("_00FF00FF"), #dark green (normal point)
CreateTexture("_FF0000FF")] #dark red (normal point)

ftex = [CreateTexture("img//ftex0.png"),
CreateTexture("img//ftex1.png"),
CreateTexture("img//ftex2.png"),
CreateTexture("img//ftex3.png"),
CreateTexture("img//ftex4.png"),
CreateTexture("img//ftex5.png"),
CreateTexture("img//ftex6.png"),
CreateTexture("img//ftex7.png"),
CreateTexture("img//ftex8.png"),
CreateTexture("img//ftex9.png"),
CreateTexture("img//ftexA.png"),
CreateTexture("img//ftexB.png"),
CreateTexture("img//ftexC.png"),
CreateTexture("img//ftexD.png"),
CreateTexture("img//ftexE.png"),
CreateTexture("img//ftexF.png"),
CreateTexture("img//ftexperiod.png"),
CreateTexture("img//ftexnegative.png")]

debugTex = [CreateTexture("img//debug.png"),
CreateTexture("img//debugonly.png"),
CreateTexture("img//debugsupporttex.png"),
CreateTexture("img//debugsupportcol.png"),
CreateTexture("img//debugoddobj.png"),
CreateTexture("img//debugoddcol.png"),
CreateTexture("img//debugall.png"),
CreateTexture("img//dtexcolon.png")]

dtex = [CreateTexture("img//dtex0.png"),
CreateTexture("img//dtex1.png"),
CreateTexture("img//dtex2.png"),
CreateTexture("img//dtex3.png"),
CreateTexture("img//dtex4.png"),
CreateTexture("img//dtex5.png"),
CreateTexture("img//dtex6.png"),
CreateTexture("img//dtex7.png"),
CreateTexture("img//dtex8.png"),
CreateTexture("img//dtex9.png"),
CreateTexture("img//dtexA.png"),
CreateTexture("img//dtexB.png"),
CreateTexture("img//dtexC.png"),
CreateTexture("img//dtexD.png"),
CreateTexture("img//dtexE.png"),
CreateTexture("img//dtexF.png"),
CreateTexture("img//dtexperiod.png"),
CreateTexture("img//dtexnegative.png")]

def LoadTexture(texdata):
	textureSurface = texdata[4]
	textureData = texdata[5]
	width = texdata[2]
	height = texdata[3]
	glEnable(GL_TEXTURE_2D)
	glBindTexture(GL_TEXTURE_2D, texdata[0])
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, textureData)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
	glEnable(GL_BLEND)
	glEnable(GL_CULL_FACE)

def DrawAxis():
	LoadTexture(commonTextures[0])
	glBegin(GL_LINES)
	glVertex3f(0, 0, 0)
	glVertex3f(1000, 0, 0)
	glEnd()
	LoadTexture(commonTextures[1])
	glBegin(GL_LINES)
	glVertex3f(0, 0, 0)
	glVertex3f(0, 1000, 0)
	glEnd()
	LoadTexture(commonTextures[2])
	glBegin(GL_LINES)
	glVertex3f(0, 0, 0)
	glVertex3f(0, 0, 1000)
	glEnd()

#the boolean value is wether or not the object is triangle polygon
objLookup = [
[True,[[0.0,-1.0,0.0],[0.7236,-0.447215,0.52572],[-0.276385,-0.447215,0.85064],[-0.276385,-0.447215,0.85064]],[[0.7236,-0.447215,0.52572],[0.0,-1.0,0.0],[0.7236,-0.447215,-0.52572],[0.7236,-0.447215,-0.52572]],[[0.0,-1.0,0.0],[-0.276385,-0.447215,0.85064],[-0.894425,-0.447215,0.0],[-0.894425,-0.447215,0.0]],[[0.0,-1.0,0.0],[-0.894425,-0.447215,0.0],[-0.276385,-0.447215,-0.85064],[-0.276385,-0.447215,-0.85064]],[[0.0,-1.0,0.0],[-0.276385,-0.447215,-0.85064],[0.7236,-0.447215,-0.52572],[0.7236,-0.447215,-0.52572]],[[0.7236,-0.447215,0.52572],[0.7236,-0.447215,-0.52572],[0.894425,0.447215,0.0],[0.894425,0.447215,0.0]],[[-0.276385,-0.447215,0.85064],[0.7236,-0.447215,0.52572],[0.276385,0.447215,0.85064],[0.276385,0.447215,0.85064]],[[-0.894425,-0.447215,0.0],[-0.276385,-0.447215,0.85064],[-0.7236,0.447215,0.52572],[-0.7236,0.447215,0.52572]],[[-0.276385,-0.447215,-0.85064],[-0.894425,-0.447215,0.0],[-0.7236,0.447215,-0.52572],[-0.7236,0.447215,-0.52572]],[[0.7236,-0.447215,-0.52572],[-0.276385,-0.447215,-0.85064],[0.276385,0.447215,-0.85064],[0.276385,0.447215,-0.85064]],[[0.7236,-0.447215,0.52572],[0.894425,0.447215,0.0],[0.276385,0.447215,0.85064],[0.276385,0.447215,0.85064]],[[-0.276385,-0.447215,0.85064],[0.276385,0.447215,0.85064],[-0.7236,0.447215,0.52572],[-0.7236,0.447215,0.52572]],[[-0.894425,-0.447215,0.0],[-0.7236,0.447215,0.52572],[-0.7236,0.447215,-0.52572],[-0.7236,0.447215,-0.52572]],[[-0.276385,-0.447215,-0.85064],[-0.7236,0.447215,-0.52572],[0.276385,0.447215,-0.85064],[0.276385,0.447215,-0.85064]],[[0.7236,-0.447215,-0.52572],[0.276385,0.447215,-0.85064],[0.894425,0.447215,0.0],[0.894425,0.447215,0.0]],[[0.276385,0.447215,0.85064],[0.894425,0.447215,0.0],[0.0,1.0,0.0],[0.0,1.0,0.0]],[[-0.7236,0.447215,0.52572],[0.276385,0.447215,0.85064],[0.0,1.0,0.0],[0.0,1.0,0.0]],[[-0.7236,0.447215,-0.52572],[-0.7236,0.447215,0.52572],[0.0,1.0,0.0],[0.0,1.0,0.0]],[[0.276385,0.447215,-0.85064],[-0.7236,0.447215,-0.52572],[0.0,1.0,0.0],[0.0,1.0,0.0]],[[0.894425,0.447215,0.0],[0.276385,0.447215,-0.85064],[0.0,1.0,0.0],[0.0,1.0,0.0]]] #berry
]

class texture:
	def __init__(self, cords, tex):
		self.cords = cords
		self.tex = CreateTexture("textures//"+tex+".png")
		self.texid = tex

class plane:
	def __init__(self, cords, group, side, ignore):
		self.cords = cords
		self.group = group
		self.side = side
		self.ignore = ignore
		self.a = 0
		self.b = 0
		self.c = 0
		self.d = 0
		t = random.randint(95, 159)
		self.tex = CreateTexture("_"+hex(t)[2:]+hex(t)[2:]+hex(t)[2:]+"9F")
		
	def update(self):
		#translate cords to slope form (calc 3 crap)
		'''
		for points g,m,n
		K=<m[x]-g[x],m[y]-g[y],m[z]-g[z]>
		P=<n[x]-g[x],n[y]-g[y],n[z]-g[z]>
		Q=normal vector
		Q=<((K[y]*P[z])-(K[z]*P[y])),((K[x]*P[z])-(K[z]*P[x])),((K[x]*P[y])-(K[y]*P[x]))>
		a=Q[x]
		b=Q[y]
		c=Q[z]
		d=-(Q[x]*g[x])+(Q[y]*g[y])+(Q[z]*g[z])
		'''
		s = [(self.cords[1][0]-self.cords[0][0]),(self.cords[1][1]-self.cords[0][1]),(self.cords[1][2]-self.cords[0][2])]
		r = [(self.cords[2][0]-self.cords[0][0]),(self.cords[2][1]-self.cords[0][1]),(self.cords[2][2]-self.cords[0][2])]
		n = [(s[1]*r[2])-(s[2]*r[1]),(s[0]*r[2])-(s[2]*r[0]),(s[0]*r[1])-(s[1]*r[0])]
		self.a = n[0]
		self.b = n[1]
		self.c = n[2]
		self.d = -abs((n[0]*self.cords[0][0])+(n[1]*self.cords[0][1])+(n[2]*self.cords[0][2]))

class obj:
	def __init__(self, cords, id, fdata, idata):
		self.cords = cords
		self.id = id
		self.fdata = fdata
		self.idata = idata
		self.tex = []
		for i in range(len(objLookup[int(self.id,16)])):
			self.tex.append(commonTextures[random.randint(7,11)])

#check if a field change request is valid before applying
def chkValid(sel):
	check = True
	if sel[1] == "":
		return False
	if sel[0] in [1,2,3,4]: #field ids that accept hex
		for i in [".","-"]:
			if i in sel[1]: check = False
		if sel[0] in [1,3]:
			if not len(sel[1]) == 4:
				check = False
		else:
			if not len(sel[1]) == 2:
				check = False
	elif sel[0] in [22,23,24,25,26,27,28,29]: #field ids that accept int
		for i in ["A","B","C","D","E","F","."]:
			if i in sel[1]: check = False
		i = 0
		for j in sel[1]:
			if j == "-":
				i+=1
		if i > 1:
			check = False
		if i == 1 and not sel[1][0] == "-":
			check = False
	else: #field ids that accept float
		i = 0
		for j in sel[1]:
			if j == ".":
				i+=1
		if i > 1:
			check = False
		if sel[1][0] == "." or sel[1][-1] == ".":
			check = False
		i = 0
		for j in sel[1]:
			if j == "-":
				i+=1
		if i > 1:
			check = False
		if i == 1 and not sel[1][0] == "-":
			check = False
		for i in ["A","B","C","D","E","F"]:
			if i in sel[1]: check = False
	return check

def applyField(sel): #set textSelect to field
	if not sel[0] in [1,2,3,4]:
		if sel[0] in [22,23,24,25,26,27,28,29]:
			sel[1] = int(sel[1])
			if sel[1] < -32768:
				sel[1] = -32768
			if sel[1] > 32767:
				sel[1] = 32767
		else:
			sel[1] = float(sel[1])
	if sel[0] == 1:
		global lvId
		lvId = sel[1]
	elif sel[0] == 2:
		global bg
		bg = sel[1]
	elif sel[0] == 3:
		texData[select[1]].tex = CreateTexture("textures//"+sel[1]+".png")
		texData[select[1]].texid = sel[1]
	elif sel[0] == 4:
		colData[select[1]].group = sel[1]
	elif sel[0] in [5,6,7] and not colData == []:
		if sMode == "ver":
			colData[select[1]].cords[select[2]][sel[0]-5] = sel[1]
			colData[select[1]].update()
		else:
			average = (colData[select[1]].cords[0][sel[0]-8]+colData[select[1]].cords[1][sel[0]-8]+colData[select[1]].cords[2][sel[0]-8])/3
			for i in range(3): colData[select[1]].cords[i][sel[0]-5] += (sel[1]-average)
	elif sel[0] in [8,9,10] and not texData == []:
		if sMode == "ver":
			texData[select[1]].cords[select[2]][sel[0]-8] = sel[1]
		else:
			average = (texData[select[1]].cords[0][sel[0]-8]+texData[select[1]].cords[1][sel[0]-8]+texData[select[1]].cords[2][sel[0]-8]+texData[select[1]].cords[3][sel[0]-8])/4
			for i in range(4): texData[select[1]].cords[i][sel[0]-8] += (sel[1]-average)
	elif sel[0] in [11,12,13] and not objData == []:
		objData[select[0]].cords[sel[0]-11] = sel[1]
	elif sel[0] in [14,15,16,17,18,19,20,21] and not objData == []:
		objData[select[0]].fdata[sel[0]-14] = sel[1]
	elif not objData == []:
		objData[select[0]].idata[sel[0]-22] = sel[1]

def stringify(number, length):
	num = str(number)
	if len(num) < length and not "." in num: #applies to idata only
		num = num+"."
	while len(num) < length: num = num+"0"
	while len(num) > length: num = num[:-1]
	return num

def getFieldVerts(cords):
	return [[-0.0704+(0.00024266666*cords[0]),-0.0436+(0.00024266666*cords[1]),0.0],
	[-0.0704+(0.00024266666*(cords[0]+3)),-0.0436+(0.00024266666*cords[1]),0.0],
	[-0.0704+(0.00024266666*(cords[0]+3)),-0.0436+(0.00024266666*(cords[1]+5)),0.0],
	[-0.0704+(0.00024266666*cords[0]),-0.0436+(0.00024266666*(cords[1]+5)),0.0]]

def getMiscVerts(cords, size):
	return [[-0.0704+(0.00024266666*cords[0]),-0.0436+(0.00024266666*cords[1]),0.0],
	[-0.0704+(0.00024266666*(cords[0]+size)),-0.0436+(0.00024266666*cords[1]),0.0],
	[-0.0704+(0.00024266666*(cords[0]+size)),-0.0436+(0.00024266666*(cords[1]+size)),0.0],
	[-0.0704+(0.00024266666*cords[0]),-0.0436+(0.00024266666*(cords[1]+size)),0.0]]

def fix(string,length):
	if len(string) > length:
		string = string[:length+1]
	elif len(string) < length:
		string = ("0"*(length-len(string)))+string
	return string

#UPDATE PLANES
i = 0
while i < len(colData):
	colData[i].update()
	i+=1

mFlag = False
mSet = [[0, 0, 0], [0, 0, 0]]
mSnap = "n"
mdAcc = 0.01

maxGroup = "00"

fps = 0
start_time=time.time()

#MAIN LOOP
while True:
	#UPDATES
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
	#clock = pygame.time.Clock()
	#clock.tick(60)
	
	#MOUSE RESETS
	mdMouse = "none"
	mChange = [[0, 0, 0], [0, 0, 0]]
	
	#PYGAME EVENTS
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			pygame.quit()
			quit()
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_0:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "0"
			if event.key == pygame.K_1:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "1"
			if event.key == pygame.K_2:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "2"
			if event.key == pygame.K_3:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "3"
			if event.key == pygame.K_4:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "4"
			if event.key == pygame.K_5:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "5"
			if event.key == pygame.K_6:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "6"
			if event.key == pygame.K_7:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "7"
			if event.key == pygame.K_8:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "8"
			if event.key == pygame.K_9:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "9"
			if event.key == pygame.K_a:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "A"
			if event.key == pygame.K_b:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "B"
			if event.key == pygame.K_c:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "C"
			if event.key == pygame.K_d:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "D"
			if event.key == pygame.K_e:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "E"
			if event.key == pygame.K_f:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "F"
			if event.key == pygame.K_MINUS:
				if not textSelect[0] == 0 and textSelect[1] == "": textSelect[1] = "-"
			if event.key == pygame.K_PERIOD:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1] + "."
			if event.key == pygame.K_BACKSPACE:
				if not textSelect[0] == 0: textSelect[1] = textSelect[1][:-1]
			if event.key == pygame.K_RETURN:
				if not textSelect[0] == 0:
					if chkValid(textSelect) == True:
						applyField(textSelect)
					textSelect = [0,""]
			if event.key == pygame.K_KP0:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_0.dmp")
			if event.key == pygame.K_KP1:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_1.dmp")
			if event.key == pygame.K_KP2:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_2.dmp")
			if event.key == pygame.K_KP3:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_3.dmp")
			if event.key == pygame.K_KP4:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_4.dmp")
			if event.key == pygame.K_KP5:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_5.dmp")
			if event.key == pygame.K_KP6:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_6.dmp")
			if event.key == pygame.K_KP7:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_7.dmp")
			if event.key == pygame.K_KP8:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_8.dmp")
			if event.key == pygame.K_KP9:
				trace = tracemalloc.take_snapshot()
				trace.dump("trace_9.dmp")
		if event.type == pygame.MOUSEBUTTONDOWN:
			if event.button == 4: mdMouse = "up"
			if event.button == 5: mdMouse = "down"
	
	#MOUSE DETECTION (PAN & ROTATE CAM)
	ky = pygame.key.get_pressed()
	mouse = pygame.mouse.get_pressed()
	mPos = pygame.mouse.get_pos()
	mRel = pygame.mouse.get_rel()
	if mouse[0] == True and mouse[2] == False and ky[306] == 0:
		if mFlag == False: #if mouse is not moving
			mRel = [0, 0]
			mSnap = "n"
			mChange = [[0, 0, 0], [0, 0, 0]]
		else: #if mouse is moving
			mChange[0][0] += mRel[0]*abs(mSet[0][2]+5)
			mChange[0][1] += mRel[1]*abs(mSet[0][2]+5)
			#check scroll
			if mdMouse == "up":
				mChange[0][2] += mdAcc
				mdAcc*=2.25
			elif mdMouse == "down":
				mChange[0][2] -= mdAcc
				mdAcc*=2.25
	elif mouse[0] == False and mouse[2] == True and ky[306] == 0:
		if mFlag == False: #if mouse is not moving
			mRel = [0, 0]
			mSnap = "n"
			mChange = [[0, 0, 0], [0, 0, 0]]
		else: #if mouse is moving
			if mSnap == "n": #if it's the first frame of pressing and a snap is not found
				if mRel[0] > mRel[1]:
					mSnap = "x"
				elif mRel[0] < mRel[1]:
					mSnap = "y"
			#when a snap is found
			if mSnap == "x":
				mChange[1][0] += mRel[0]
			elif mSnap == "y":
				mChange[1][1] += mRel[1]
			#check scroll
			if mdMouse == "up": mChange[1][2] += 0.1
			elif mdMouse == "down": mChange[1][2] -= 0.1
	mdAcc/=1.2
	if mdAcc <= 0.01: mdAcc = 0.01
	
	#ADD mChange TO mSet
	mSet[0][0] += mChange[0][0]
	mSet[0][1] += mChange[0][1]
	mSet[0][2] += mChange[0][2]
	mSet[1][0] += mChange[1][0]
	mSet[1][1] += mChange[1][1]
	mSet[1][2] += mChange[1][2]
	
	#CONTROL PANNEL
	if mouse[0] == True and mFlag == False and mPos[0] < 100:
		button = -1
		loop = -1
		for i in bttnCordLookup:
			loop+=1
			if mPos[0] >= i[0] and mPos[1] >= i[1] and mPos[0] <= i[2] and mPos[1] <= i[3]:
				button = loop
		if button == 0: #new
			lvId = "0000"
			bg = "00"
			texData = []
			colData = []
			objData = []
		elif button == 1: #load
			bg = "00"
			objData = []
			texData = []
			colData = []
			with open("saves//"+lvId+".uwl", 'rb') as file:
				data = file.read()
			data = binascii.hexlify(data).decode("utf-8")
			bg = data[:2]
			lens = [0,0]
			lens[0] = int(data[2:6],16)
			lens[1] = int(data[6+(100*lens[0]):8+(100*lens[0])],16)
			#get tex data
			if lens[0] != 0:
				for i in range(lens[0]):
					offset = 6+(100*i)
					cords = []
					for j in range(12):
						cords.append(struct.unpack('!f',bytes.fromhex(data[offset+(8*j):8+offset+(8*j)]))[0])
					tex = data[102+(100*i):106+(100*i)]
					texData.append(texture([[cords[0],cords[1],cords[2]],[cords[3],cords[4],cords[5]],[cords[6],cords[7],cords[8]],[cords[9],cords[10],cords[11]]],tex))
			#get col data
			offset = 10+(lens[0]*100)
			if lens[1] != 0:
				for i in range(lens[1]): #for every group
					for j in range(int(data[offset-2:offset],16)): #for every plane
						cords = []
						slope = []
						for k in range(9): #for every cord
							cords.append(struct.unpack('!f',bytes.fromhex(data[offset+(8*k):offset+8+(8*k)]))[0])
						for k in range(4): #for every slope
							slope.append(struct.unpack('!f',bytes.fromhex(data[offset+72+(8*k):offset+80+(8*k)]))[0])
						flags = data[offset+104:offset+106]
						flags = [fix(bin(int(flags,16))[2:],8)[-2],fix(bin(int(flags,16))[2:],8)[-1]]
						if flags[0] == "1": flags[0] = True
						else: flags[0] = False
						if flags[1] == "1": flags[1] = True
						else: flags[1] = False
						colData.append(plane([[cords[0],cords[1],cords[2]],[cords[3],cords[4],cords[5]],[cords[6],cords[7],cords[8]]],fix(hex(i)[2:],2),flags[0],flags[1]))
						offset+=108
					offset+=2
			offset-=2
			#get obj data
			if not int(data[offset-2:offset],16) == 0:
				for i in range(int(data[offset-2:offset],16)): #for every object
					id = data[offset:offset+2]
					cords = []
					fdata = []
					idata = []
					for j in range(3): #for every cord
						cords.append(struct.unpack('!f',bytes.fromhex(data[offset+2+(8*j):offset+10+(8*j)]))[0])
					for j in range(8): #for every fdata
						fdata.append(struct.unpack('!f',bytes.fromhex(data[offset+26+(8*j):offset+34+(8*j)]))[0])
					for j in range(8): #for every idata
						idata.append(int(data[offset+90+(4*j):offset+94+(4*j)],16)-32768)
					objData.append(obj(cords,id,fdata,idata))
					offset+=122
		elif button == 2: #save
			temp = bg
			temp = temp + fix(hex(len(texData))[2:],4)
			if not texData == []:
				#get texture data
				for i in texData:
					for j in i.cords:
						for k in j:
							temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',k))[0])[2:],8)
					temp = temp + fix(i.texid,4)
			#get groups
			groupTrack = []
			amountTrack = []
			for i in colData:
				if not i.group in groupTrack:
					groupTrack.append(i.group)
			temp = temp + fix(hex(len(groupTrack))[2:],2)
			if not groupTrack == []:
				#get number of planes per group
				for i in groupTrack:
					amount = 0
					for j in colData:
						if j.group == i:
							amount+=1
					amountTrack.append(amount)
				#get col data
				for i in range(len(groupTrack)):
					temp = temp + fix(hex(amountTrack[i])[2:],2)
					for j in colData:
						if j.group == groupTrack[i]:
							for k in j.cords:
								for m in k:
									temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',m))[0])[2:],8)
							temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',j.a))[0])[2:],8)
							temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',j.b))[0])[2:],8)
							temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',j.c))[0])[2:],8)
							temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',j.d))[0])[2:],8)
							flags = ["",""]
							if j.side == True: flags[0] = "1"
							else: flags[0] = "0"
							if j.ignore == True: flags[0] = "1"
							else: flags[0] = "0"
							temp = temp + fix(hex(int(flags[0]+flags[1],2))[2:],2)
			temp = temp + fix(hex(len(objData))[2:],2)
			if not objData == []:
				#get obj data
				for i in objData:
					temp = temp + i.id
					for j in i.cords:
						temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',j))[0])[2:],8)
					for j in i.fdata:
						temp = temp + fix(hex(struct.unpack('<I',struct.pack('<f',j))[0])[2:],8)
					for j in i.idata:
						temp = temp + fix(hex(j+32768)[2:],4)
			#convert data to bytes and export file
			data = binascii.unhexlify(temp)
			file = open("saves//"+lvId+".uwl", "a")
			file.close()
			file = open("saves//"+lvId+".uwl", "wb")
			file.write(data)
			file.close()
		elif button == 3:
			if sMode == "obj":
				objData.append(obj([0.0,0.0,0.0],"00",[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],[0,0,0,0,0,0,0,0]))
			else:
				if mMode == "tex":
					texData.append(texture([[0.01,0.01,0.01],[0.02,0.01,0.01],[0.02,0.02,0.02],[0.01,0.02,0.02]],"0000"))
				else:
					colData.append(plane([[0.01,0.01,0.01],[0.02,0.01,0.01],[0.02,0.02,0.02]],"00",True,False))
					colData[-1].update()
		elif button == 4:
			if exView == 3: exView = 0
			else: exView+=1
		elif button == 5:
			if sMode == "obj" and not objData == []:
				if len(objData) == 1:
					objData = []
				elif select[0] == 0:
					objData = objData[1:]
				elif select[0] == len(objData)-1:
					objData = objData[:-1]
					select[0]-=1
				elif select[0] < len(objData):
					objData = objData[:select[0]] + objData[select[0]+1:]
			elif mMode == "tex" and not texData == []:
				if len(texData) == 1:
					texData = []
				elif select[1] == 0:
					texData = texData[1:]
				elif select[1] == len(texData)-1:
					texData = texData[:-1]
					select[1]-=1
				elif select[1] < len(texData):
					texData = texData[:select[1]] + texData[select[1]+1:]
			elif mMode == "col" and not colData == []:
				if len(colData) == 1:
					colData = []
				elif select[1] == 0:
					colData = colData[1:]
				elif select[1] == len(colData)-1:
					colData = colData[:-1]
					select[1]-=1
				elif select[1] < len(colData):
					colData = colData[:select[1]] + colData[select[1]+1:]
		elif button == 6:
			if sMode == "obj" and select[0]-selAcc[1] >= 0:
				select[0]-=selAcc[1]
				selAcc[0] = 60
				selAcc[1]*=2
			elif sMode == "pln" and select[1]-selAcc[1] >= 0:
				select[1]-=selAcc[1]
				selAcc[0] = 60
				selAcc[1]*=2
			elif sMode == "ver" and select[2] > 0:
				select[2]-=1
		elif button == 7:
			if sMode == "obj" and select[0]+selAcc[3] <= len(objData)-1:
				select[0]+=selAcc[3]
				selAcc[2] = 60
				selAcc[3]*=2
			elif sMode == "pln":
				if mMode == "tex" and select[1]+selAcc[3] <= len(texData)-1:
					select[1]+=selAcc[3]
					selAcc[2] = 60
					selAcc[3]*=2
				elif mMode == "col" and select[1]+selAcc[3] <= len(colData)-1:
					select[1]+=selAcc[3]
					selAcc[2] = 60
					selAcc[3]*=2
			elif sMode == "ver":
				if mMode == "tex" and select[2] < 3:
					select[2]+=1
				elif mMode == "col" and select[2] < 2:
					select[2]+=1
		elif button == 8:
			mMode = "tex"
		elif button == 9:
			mMode = "col"
		elif button == 10:
			sMode = "obj"
		elif button == 11:
			sMode = "pln"
		elif button == 12:
			sMode = "ver"
			select[2] = 0
		elif button == 13:
			textSelect[0] = 1
		elif button == 14:
			textSelect[0] = 2
		elif button == 15:
			textSelect[0] = 3
		elif button == 16:
			textSelect[0] = 4
		elif button == 17:
			if not colData == []:
				colData[select[1]].side = True
		elif button == 18:
			if not colData == []:
				colData[select[1]].side = False
		elif button == 19:
			if not colData == []:
				if colData[select[1]].ignore == False:
					colData[select[1]].ignore = True
				else:
					colData[select[1]].ignore = False
		elif button == 20:
			textSelect[0] = 5
		elif button == 21:
			textSelect[0] = 6
		elif button == 22:
			textSelect[0] = 7
		elif button == 23:
			textSelect[0] = 8
		elif button == 24:
			textSelect[0] = 9
		elif button == 25:
			textSelect[0] = 10
		elif button == 26:
			textSelect[0] = 11
		elif button == 27:
			textSelect[0] = 12
		elif button == 28:
			textSelect[0] = 13
		elif button == 29:
			textSelect[0] = 14
		elif button == 30:
			textSelect[0] = 15
		elif button == 31:
			textSelect[0] = 16
		elif button == 32:
			textSelect[0] = 17
		elif button == 33:
			textSelect[0] = 18
		elif button == 34:
			textSelect[0] = 19
		elif button == 35:
			textSelect[0] = 20
		elif button == 36:
			textSelect[0] = 21
		elif button == 37:
			textSelect[0] = 22
		elif button == 38:
			textSelect[0] = 23
		elif button == 39:
			textSelect[0] = 24
		elif button == 40:
			textSelect[0] = 25
		elif button == 41:
			textSelect[0] = 26
		elif button == 42:
			textSelect[0] = 27
		elif button == 43:
			textSelect[0] = 28
		elif button == 44:
			textSelect[0] = 29
	
	if mouse[0] == False and mouse[2] == False: mFlag = False
	else: mFlag = True
	
	#CAMERA RESET KEYS
	if ky[112] == 1: mSet[0] = [0, 0, 0]
	if ky[114] == 1: mSet[1] = [0, 0, 0]
	
	#CAMERA CRAP
	glTranslatef(mSet[0][0]/5000, mSet[0][1]/-5000, mSet[0][2])
	glRotatef(mSet[1][1]/10, 1.0, 0.0, 0.0)
	glRotatef(mSet[1][0]/-10, 0.0, 1.0, 0.0)
	glRotatef(mSet[1][2]*10, 0.0, 0.0, 1.0)
	
	glTranslatef(0.012195, 0, 0)
	
	#DRAW AXIS LABELS
	Verts = [[0.015,0.015,0],[0.001,0.015,0],[0.001,0.001,0],[0.015,0.001,0],[0,0.015,0.015],[0,0.001,0.015],[0,0.001,0.001],[0,0.015,0.001],[0.015,0,0.015],[0.001,0,0.015],[0.001,0,0.001],[0.015,0,0.001],[0.01,0.005,0],[0.002,0.005,0],[0.002,0.002,0],[0.01,0.002,0]]
	Faces = [[2,3,0,1],[5,6,7,4],[10,9,8,11],[14,15,12,13]]
	Textures = [commonTextures[4],commonTextures[4],commonTextures[4],commonTextures[5]]
	TextureOffsets = ((0,0),(1,0),(1,1),(0,1))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DETERMINE IF OBJ, TEX, AND COL DATA IS DRAWN
	draws = [False, False, False]
	if sMode == "obj":
		if exView == 0: draws = [True, False, False]
		elif exView == 1: draws = [True, True, False]
		elif exView == 2: draws = [True, False, True]
		elif exView == 3: draws = [True, True, True]
	elif mMode == "tex":
		if exView == 0: draws = [False, True, False]
		elif exView == 1: draws = [False, True, True]
		elif exView == 2: draws = [True, True, False]
		elif exView == 3: draws = [True, True, True]
	elif mMode == "col":
		if exView == 0: draws = [False, False, True]
		elif exView == 1: draws = [False, True, True]
		elif exView == 2: draws = [True, False, True]
		elif exView == 3: draws = [True, True, True]
	
	#DRAW OBJDATA
	if draws[0] == True:
		TextureOffsets = ((0,0),(1,0),(1,1),(0,1))
		for i in objData:
			tx = -1
			for j in objLookup[int(i.id,16)][1:]:
				tx+=1
				LoadTexture(objData[select[0]].tex[tx])
				Txl = -1
				glBegin(GL_QUADS)
				for k in range(4):
					Txl+=1
					glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
					glVertex3fv([j[k][0]+i.cords[0],j[k][1]+i.cords[1],j[k][2]+i.cords[2]])
				glEnd()
	
	#DRAW TEXDATA
	if draws[1] == True:
		TextureOffsets = ((0,0),(1,0),(1,1),(0,1))
		for i in texData:
			LoadTexture(i.tex)
			Txl = -1
			glBegin(GL_QUADS)
			for j in range(4):
				Txl+=1
				glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
				glVertex3fv(i.cords[j])
			glEnd()
	
	#DRAW COLDATA
	if draws[2] == True:
		TextureOffsets = ((0,0),(1,0),(1,1),(0,1))
		for i in colData:
			LoadTexture(i.tex)
			Txl = -1
			glBegin(GL_TRIANGLES)
			for j in range(3):
				Txl+=1
				glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
				glVertex3fv(i.cords[j])
			glEnd()
	
	#DRAW NORMAL POINT
	if not colData == [] and mMode == "col":
		norm = [colData[select[1]].a,colData[select[1]].b,colData[select[1]].c,colData[select[1]].d]
		point = [norm[0],norm[1],norm[2]]
		rside = (norm[0]*norm[0])+(norm[1]*norm[1])-(norm[2]*norm[2])+(norm[3]*norm[3])

		glPointSize(5)
		if colData[select[1]].side == True:
			if 0 < rside: LoadTexture(commonTextures[15])
			else: LoadTexture(commonTextures[16])
		else:
			if 0 > rside: LoadTexture(commonTextures[15])
			else: LoadTexture(commonTextures[16])
		glBegin(GL_POINTS)
		glVertex3d(point[0], point[1], point[2])
		glEnd()
	
	#DRAW TEST POINT
	point = [0.0,0.0,0.0]
	if sMode == "obj" and not objData == []:
		for i in objLookup[select[0]][1:]:
			items = 3
			if objLookup[select[0]][0] == False:
				items+=1
			for j in i[:items]:
				point[0]+=j[0]
				point[1]+=j[1]
				point[2]+=j[2]
		point[0]/=len(objLookup[select[0]])
		point[1]/=len(objLookup[select[0]])
		point[2]/=len(objLookup[select[0]])
	elif mMode == "tex" and not texData == []:
		if sMode == "pln":
			for i in texData[select[1]].cords:
				point[0]+=i[0]
				point[1]+=i[1]
				point[2]+=i[2]
			point[0]/=4
			point[1]/=4
			point[2]/=4
		elif sMode == "ver":
			point = texData[select[1]].cords[select[2]]
	elif mMode == "col" and not colData == []:
		if sMode == "pln":
			for i in colData[select[1]].cords:
				point[0]+=i[0]
				point[1]+=i[1]
				point[2]+=i[2]
			point[0]/=3
			point[1]/=3
			point[2]/=3
		elif sMode == "ver":
			point = colData[select[1]].cords[select[2]]
	
	glPointSize(5)
	LoadTexture(commonTextures[3])
	glBegin(GL_POINTS)
	glVertex3d(point[0], point[1], point[2])
	glEnd()
	
	DrawAxis()
	glTranslatef(-0.012195, 0, 0)
	
	#RETURN CAMERA
	glRotatef(mSet[1][2]*10, 0.0, 0.0, -1.0)
	glRotatef(mSet[1][0]/-10, 0.0, -1.0, 0.0)
	glRotatef(mSet[1][1]/10, -1.0, 0.0, 0.0)
	glTranslatef(-(mSet[0][0]/5000), -(mSet[0][1]/-5000), -(mSet[0][2]))
	
	#DRAW CONTROL PANNEL
	Verts = [[-0.0704,-0.0436,0],[-0.0461,-0.0436,0],[-0.0461,0.0436,0],[-0.0704,0.0436,0]]
	Faces = [[0,1,2,3]]
	Textures = [commonTextures[6]]
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#GET FIELD TEXT TEXTURES
	Textures = []
	for i in lvId: Textures.append(ftex[int(i,16)])
	for i in bg: Textures.append(ftex[int(i,16)])
	if not texData == [] and mMode == "tex":
		for i in texData[select[1]].texid: Textures.append(ftex[int(i,16)])
	if not colData == [] and mMode == "col":
		for i in colData[select[1]].group: Textures.append(ftex[int(i,16)])
	
	if sMode == "obj" and not objData == []:
		for i in objData[select[0]].cords:
			for j in stringify(i,22):
				if j == ".": Textures.append(ftex[16])
				elif j == "-": Textures.append(ftex[17])
				else: Textures.append(ftex[int(j,16)])
		for i in objData[select[0]].fdata:
			for j in stringify(i,20):
				if j == ".": Textures.append(ftex[16])
				elif j == "-": Textures.append(ftex[17])
				else: Textures.append(ftex[int(j,16)])
		for i in objData[select[0]].idata:
			for j in stringify(i,6):
				if j == "-": Textures.append(ftex[17])
				elif j == ".": Textures.append(ftex[16])
				else: Textures.append(ftex[int(j,16)])
	elif mMode == "tex" and not texData == []:
		if sMode == "pln":
			cor = texData[select[0]].cords
			for i in [(cor[0][0]+cor[1][0]+cor[2][0]+cor[3][0])/4,(cor[0][1]+cor[1][1]+cor[2][1]+cor[3][1])/4,(cor[0][2]+cor[1][2]+cor[2][2]+cor[3][2])/4]:
				for j in stringify(i,22):
					if j == ".": Textures.append(ftex[16])
					elif j == "-": Textures.append(ftex[17])
					else: Textures.append(ftex[int(j,16)])
		elif sMode == "ver":
			for i in texData[select[1]].cords[select[2]]:
				for j in stringify(i,22):
					if j == ".": Textures.append(ftex[16])
					elif j == "-": Textures.append(ftex[17])
					else: Textures.append(ftex[int(j,16)])
	elif mMode == "col" and not colData == []:
		if sMode == "pln":
			cor = colData[select[0]].cords
			for i in [(cor[0][0]+cor[1][0]+cor[2][0])/3,(cor[0][1]+cor[1][1]+cor[2][1])/3,(cor[0][2]+cor[1][2]+cor[2][2])/3]:
				for j in stringify(i,22):
					if j == ".": Textures.append(ftex[16])
					elif j == "-": Textures.append(ftex[17])
					else: Textures.append(ftex[int(j,16)])
		elif sMode == "ver":
			for i in colData[select[1]].cords[select[2]]:
				for j in stringify(i,22):
					if j == ".": Textures.append(ftex[16])
					elif j == "-": Textures.append(ftex[17])
					else: Textures.append(ftex[int(j,16)])
	
	#GET FIELD TEXT CORDS AND FACES
	Verts = []
	
	Verts.append(getFieldVerts([11,294])) #level id
	Verts.append(getFieldVerts([15,294]))
	Verts.append(getFieldVerts([19,294]))
	Verts.append(getFieldVerts([23,294]))
	Verts.append(getFieldVerts([31,294])) #level bg
	Verts.append(getFieldVerts([35,294]))
	if not texData == [] and mMode == "tex":
		Verts.append(getFieldVerts([75,294])) #texture
		Verts.append(getFieldVerts([79,294]))
		Verts.append(getFieldVerts([83,294]))
		Verts.append(getFieldVerts([87,294]))
	if not colData == [] and mMode == "col":
		Verts.append(getFieldVerts([23,274])) #group
		Verts.append(getFieldVerts([27,274]))
	
	if sMode == "obj" and not objData == []:
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),184])) #obj x
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),174])) #obj y
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),164])) #obj z
		for i in range(8): #fdata
			for j in range(20):
				Verts.append(getFieldVerts([15+(j*4),154-(i*10)]))
		for i in range(6): Verts.append(getFieldVerts([15+(i*4),74])) #idata1
		for i in range(6): Verts.append(getFieldVerts([55+(i*4),74])) #idata2
		for i in range(6): Verts.append(getFieldVerts([15+(i*4),64])) #idata3
		for i in range(6): Verts.append(getFieldVerts([55+(i*4),64])) #idata4
		for i in range(6): Verts.append(getFieldVerts([15+(i*4),54])) #idata5
		for i in range(6): Verts.append(getFieldVerts([55+(i*4),54])) #idata6
		for i in range(6): Verts.append(getFieldVerts([15+(i*4),44])) #idata7
		for i in range(6): Verts.append(getFieldVerts([55+(i*4),44])) #idata8
	elif mMode == "tex" and not texData == []:
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),224])) #pln x
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),214])) #pln y
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),204])) #pln z
	elif mMode == "col" and not colData == []:
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),264])) #col x
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),254])) #col y
		for i in range(22): Verts.append(getFieldVerts([7+(i*4),244])) #col z
	
	Faces = []
	
	for i in range(len(Verts)):
		Faces.append([0+(i*4),1+(i*4),2+(i*4),3+(i*4)])
	
	Verty = []
	
	for i in Verts:
		for j in i:
			Verty.append(j)
	
	Verts = Verty
	
	#DRAW FIELD TEXT
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#MISC. LABELS (sMODE/mMODE SELECT, SIDE/IGNORE SELECT)
	Textures = [commonTextures[12],commonTextures[12]]
	if not colData == []:
		if mMode == "col":
			Textures.append(commonTextures[13]) #side
			if colData[select[1]].ignore == True:
				Textures.append(commonTextures[14]) #ignore
	
	Verts = []
	if mMode == "tex":
		Verts.append(getMiscVerts([3,312],7))
	elif mMode == "col":
		Verts.append(getMiscVerts([19,312],7))
	if sMode == "obj":
		Verts.append(getMiscVerts([58,312],7))
	elif sMode == "pln":
		Verts.append(getMiscVerts([74,312],7))
	elif sMode == "ver":
		Verts.append(getMiscVerts([90,312],7))
	if not colData == []:
		if mMode == "col":
			if colData[select[1]].side == True: #side
				Verts.append(getMiscVerts([49,272],5))
			elif colData[select[1]].side == False:
				Verts.append(getMiscVerts([57,272],5))
			if colData[select[1]].ignore == True:
				Verts.append(getMiscVerts([87,274],5)) #ignore
	
	Faces = []
	for i in range(len(Verts)):
		Faces.append([0+(i*4),1+(i*4),2+(i*4),3+(i*4)])
	
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DRAW DEBUG LABEL
	Textures = [debugTex[0]]
	Verts = [getMiscVerts([100,310.5],49)]
	Verts = Verts[0]
	Faces = [[0,1,2,3]]
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DEBUG: exView
	Textures = []
	cord = [0,0]
	if sMode == "obj":
		if exView == 0:
			Textures.append(debugTex[1])
			cord = [343,15]
		elif exView == 1:
			Textures.append(debugTex[2])
			cord = [307,51]
		elif exView == 2:
			Textures.append(debugTex[5])
			cord = [323,35]
		elif exView == 3:
			Textures.append(debugTex[6])
			cord = [347,11]
	elif mMode == "tex":
		if exView == 0:
			Textures.append(debugTex[1])
			cord = [343,15]
		elif exView == 1:
			Textures.append(debugTex[3])
			cord = [307,51]
		elif exView == 2:
			Textures.append(debugTex[4])
			cord = [323,35]
		elif exView == 3:
			Textures.append(debugTex[6])
			cord = [347,11]
	elif mMode == "col":
		if exView == 0:
			Textures.append(debugTex[1])
			cord = [343,15]
		elif exView == 1:
			Textures.append(debugTex[2])
			cord = [307,51]
		elif exView == 2:
			Textures.append(debugTex[4])
			cord = [323,35]
		elif exView == 3:
			Textures.append(debugTex[6])
			cord = [347,11]
	
	Verts = [getMiscVerts([134,cord[0]],cord[1])]
	Verts = Verts[0]
	Faces = [[0,1,2,3]]
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DEBUG: maxGroup
	Textures = [dtex[int(maxGroup[0],16)],dtex[int(maxGroup[1],16)]]
	Verts = [getFieldVerts([134,347]),getFieldVerts([138,347])]
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	Faces = [[0,1,2,3],[4,5,6,7]]
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DEBUG: select
	sSelect = [str(select[0]),str(select[1]),str(select[2])] #string select
	Textures = []
	Verts = []
	Faces = []
	
	offset = 0
	for i in range(3):
		for j in sSelect[i]:
			Textures.append(dtex[int(j)])
			Verts.append(getFieldVerts([134+(offset*4),341]))
			Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
			offset+=1
		if i != 2:
			Textures.append(debugTex[7])
			Verts.append(getFieldVerts([134+(offset*4),341]))
			Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
			offset+=1
	
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DEBUG: textSelect
	sTextSelect = [str(textSelect[0]),str(textSelect[1])] #string textSelect
	Textures = []
	Verts = []
	Faces = []
	
	offset = 0
	for i in sTextSelect[0]:
		Textures.append(dtex[int(i)])
		Verts.append(getFieldVerts([134+(offset*4),335.5]))
		Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
		offset+=1
	Textures.append(debugTex[7])
	Verts.append(getFieldVerts([134+(offset*4),335.5]))
	Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
	offset+=1
	for i in sTextSelect[1]:
		if not i in [".","-"]:
			Textures.append(dtex[int(i,16)])
		elif i == ".":
			Textures.append(dtex[16])
		elif i == "-":
			Textures.append(dtex[17])
		Verts.append(getFieldVerts([134+(offset*4),335.5]))
		Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
		offset+=1
	
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DEBUG: selAcc
	sSelAcc = [str(selAcc[0]),str(selAcc[1]),str(selAcc[2]),str(selAcc[3])] #string selAcc
	Textures = []
	Verts = []
	Faces = []
	
	offset = 0
	for i in range(4):
		for j in sSelAcc[i]:
			Textures.append(dtex[int(j)])
			Verts.append(getFieldVerts([134+(offset*4),330]))
			Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
			offset+=1
		if i != 3:
			Textures.append(debugTex[7])
			Verts.append(getFieldVerts([134+(offset*4),330]))
			Faces.append([0+(offset*4),1+(offset*4),2+(offset*4),3+(offset*4)])
			offset+=1
	
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#DEBUG: objs, plns, cols
	amounts = [str(len(objData)),str(len(texData)),str(len(colData))]
	Textures = []
	Verts = []
	Faces = []
	
	offset = [0,0]
	for i in range(3):
		for j in amounts[i]:
			Textures.append(dtex[int(j)])
			Verts.append(getFieldVerts([134+(offset[0]*4),312+(i*6)]))
			Faces.append([0+(offset[1]*4),1+(offset[1]*4),2+(offset[1]*4),3+(offset[1]*4)])
			offset[0]+=1
			offset[1]+=1
		offset[0] = 0
	
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	#UPDATE selAcc
	if selAcc[0] > 0: selAcc[0]-=1
	if selAcc[2] > 0: selAcc[2]-=1
	if selAcc[0] == 0: selAcc[1] = 1
	if selAcc[2] == 0: selAcc[3] = 1
	
	#UPDATE maxGroup
	maxGroup = "00"
	if not colData == []:
		for i in colData:
			if int(i.group,16) > int(maxGroup,16): maxGroup = i.group
	
	#GET AND DRAW FPS
	fps = 1/(time.time()-start_time)
	start_time=time.time()
	fps = str(round(fps))
	if len(fps) == 1:
		fps = "00"+fps
	elif len(fps) == 2:
		fps = "0"+fps
	elif len(fps) > 3:
		fps = fps[0:3]
	
	Textures = [dtex[int(fps[0])],dtex[int(fps[1])],dtex[int(fps[2])]]
	Verts = [getFieldVerts([568,353]),getFieldVerts([572,353]),getFieldVerts([576,353])]
	
	Verty = []
	for i in Verts:
		for j in i:
			Verty.append(j)
	Verts = Verty
	
	Faces = [[0,1,2,3],[4,5,6,7],[8,9,10,11]]
	TextureOffsets = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
	Tex = 0
	for poly in Faces:
		LoadTexture(Textures[Tex])
		Tex+=1
		Txl = -1
		glBegin(GL_QUADS)
		for vertex in poly:
			Txl+=1
			glTexCoord2f(TextureOffsets[Txl][0], TextureOffsets[Txl][1])
			glVertex3fv(Verts[vertex])
		glEnd()
	
	pygame.display.flip()